#pragma once

using namespace std;

class Batiment {

private:

public:

}