#pragma once
#include "BatimentResidentiel.h"

using namespace std;

BatimentResidentiel::BatimentResidentiel(const int h, const int l, pair<int, int> c, const int cap)
{

}

BatimentResidentiel::BatimentResidentiel(const BatimentResidentiel &)
{

}

BatimentResidentiel::~BatimentResidentiel()
{

}
