#include "BatimentUtilitaire.h"

BatimentUtilitaire::BatimentUtilitaire(const int h, const int l, pair<int, int> c, const int type)
{

}

BatimentUtilitaire::BatimentUtilitaire(const BatimentUtilitaire &)
{

}

BatimentUtilitaire::~BatimentUtilitaire()
{

}
